<div id="left">
			<form action="search-results.html" method="GET" class='search-form'>
				<div class="search-pane">
					<input type="text" name="search" placeholder="Search here...">
					<button type="submit"><i class="icon-search"></i></button>
				</div>
			</form>
			<div class="subnav">
				<div class="subnav-title">
					<a href="#" class='toggle-subnav'><i class="icon-angle-down"></i><span>Content</span></a>
				</div>
				<ul class="subnav-menu">
				<li>
						<a href="index.php"> Dashboard</a>
					</li>
					<li class='dropdown'>
						<a href="#" data-toggle="dropdown">Kategori</a>
						<ul class="dropdown-menu">
							<li>
								<a href="content.php?page=tambah-kategori">Tambah Kategori</a>
							</li>
							<li>
								<a href="content.php?page=data-kategori">Data Kategori</a>
							</li>
							
						</ul>
					</li>
					<li class='dropdown'>
						<a href="#" data-toggle="dropdown">Jenis Warung Makan</a>
						<ul class="dropdown-menu">
							<li>
								<a href="content.php?page=tambah-jenis-warung">Tambah Jenis Warung Makan</a>
							</li>
							<li>
								<a href="content.php?page=data-jenis-warung">Data Jenis Warung Makan</a>
							</li>
							
						</ul>
					</li>
					<li class='dropdown'>
						<a href="#" data-toggle="dropdown">Nama Warung Makan</a>
						<ul class="dropdown-menu">
							<li>
								<a href="content.php?page=tambah-warung-makan">Tambah  Warung Makan</a>
							</li>
							<li>
								<a href="content.php?page=data-warung-makan">Data Warung Makan</a>
							</li>
							
						</ul>
					</li>
				</ul>
			</div>
			<div class="subnav">
				<div class="subnav-title">
					<a href="#" class='toggle-subnav'><i class="icon-angle-down"></i><span>Menu</span></a>
				</div>
				<ul class="subnav-menu">
					<li class='dropdown'>
						<a href="#" data-toggle="dropdown">Menu Makanan</a>
						<ul class="dropdown-menu">
							<li>
								<a href="content.php?page=tambah-menu">Tambah Menu</a>
							</li>
							<li>
								<a href="content.php?page=data-menu">Data Menu</a>
							</li>

						</ul>
					</li>
					<li class='dropdown'>
						<a href="#" data-toggle="dropdown">Promo Menu</a>
						<ul class="dropdown-menu">
							<li>
								<a href="content.php?page=tambah-promo">Tambah Promo</a>
							</li>
							<li>
								<a href="content.php?page=data-promo">Data Promo</a>
							</li>
							
						</ul>
					</li>
					
				</ul>
			</div>
			<div class="subnav">
				<div class="subnav-title">
					<a href="#" class='toggle-subnav'><i class="icon-angle-down"></i><span>Pesanan</span></a>
				</div>
				<ul class="subnav-menu">
					<li class='dropdown'>
						<a href="#" data-toggle="dropdown">Pesanan</a>
						<ul class="dropdown-menu">
							
							<li>
								<a href="content.php?page=data-pesanan">Data Pesanan</a>
							</li>
							
						</ul>
					</li>
				</ul>
			</div>
			
		</div>