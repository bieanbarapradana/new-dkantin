<?php 
	
	include "../../include/koneksi.php";

		$jenis=$_POST['jenis'];
		$warung=$_POST['warung'];

		mysql_query("INSERT INTO tb_isi_sub_kategori VALUES (NULL,'$jenis','$warung') ");

		header("location: ../content.php?page=data-warung-makan");

 ?>